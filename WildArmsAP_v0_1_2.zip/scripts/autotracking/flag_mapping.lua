FLAG_MAPPING = {
    [41970238] = "can_sail_inner_sea",
    [41970012] = "defeated_belselk_1",
    [41970434] = "defeated_mother",
    [41970392] = "defeated_orga_widow",
    [41970314] = "defeated_zeik_tuvai",
}
