CUR_INDEX = -1

function onClear(slot_data)
    CUR_INDEX = -1
    MAP_KEY = "wildarms_current_map_" .. Archipelago.TeamNumber .. "_" .. Archipelago.PlayerNumber
    Archipelago:SetNotify({MAP_KEY})
    Archipelago:Get({MAP_KEY})
    for _, v in pairs(LOCATION_MAPPING) do
        local obj = Tracker:FindObjectForCode(v[1])
        if obj then obj.AvailableChestCount = obj.ChestCount end
    end
    for _, code in pairs(FLAG_MAPPING) do
        local obj = Tracker:FindObjectForCode(code)
        if obj then obj.Active = false end
    end
    for _, v in pairs(ITEM_MAPPING) do
        local obj = Tracker:FindObjectForCode(v[1])
        if obj then
            if v[2] == "toggle" then obj.Active = false
            elseif v[2] == "consumable" then obj.AcquiredCount = 0
            elseif v[2] == "progressive" then obj.CurrentStage = 0 end
        end
    end
    if slot_data then
        for code, key in pairs(OPTION_MAPPING) do
            local obj = Tracker:FindObjectForCode(code)
            if obj and slot_data[key] ~= nil then obj.Active = (slot_data[key] == true or slot_data[key] == 1) end
        end
    end
end

function onItem(index, item_id, item_name, player_number)
    if index <= CUR_INDEX then return end
    CUR_INDEX = index
    local v = ITEM_MAPPING[item_id]
    if not v then return end
    local obj = Tracker:FindObjectForCode(v[1])
    if not obj then return end
    if v[2] == "toggle" then
        obj.Active = true
    elseif v[2] == "consumable" then
        obj.AcquiredCount = obj.AcquiredCount + 1
    elseif v[2] == "progressive" then
        obj.CurrentStage = obj.CurrentStage + 1
    end
end

function onLocation(location_id, location_name)
    local flag_code = FLAG_MAPPING[location_id]
    if flag_code then
        local flag_obj = Tracker:FindObjectForCode(flag_code)
        if flag_obj then flag_obj.Active = true end
    end
    local v = LOCATION_MAPPING[location_id]
    if not v then return end
    local obj = Tracker:FindObjectForCode(v[1])
    if obj then obj.AvailableChestCount = obj.AvailableChestCount - 1 end
end

function onMapSwitch(key, value, oldValue)
    if key ~= MAP_KEY then return end
    local tab = MAP_TAB[value]
    if tab then Tracker:UiHint("ActivateTab", tab) end
end

Archipelago:AddClearHandler("clear handler", onClear)
Archipelago:AddItemHandler("item handler", onItem)
Archipelago:AddLocationHandler("location handler", onLocation)
Archipelago:AddSetReplyHandler("map switch handler", onMapSwitch)
Archipelago:AddRetrievedHandler("map retrieved handler", onMapSwitch)
