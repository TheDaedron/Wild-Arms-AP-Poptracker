OPTION_MAPPING = {
    ["dark_room_tricks"] = "dark_room_tricks",
    ["risky_treasures"] = "risky_treasures",
}
