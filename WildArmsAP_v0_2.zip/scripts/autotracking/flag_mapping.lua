FLAG_MAPPING = {
    [41970236] = "can_sail_inner_sea",
    [41970075] = "can_use_elw_pyramids",
    [41970012] = "defeated_belselk_1",
    [41970427] = "defeated_mother",
    [41970307] = "defeated_zeik_tuvai",
}
